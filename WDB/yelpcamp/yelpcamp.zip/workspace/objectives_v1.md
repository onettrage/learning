Pt.1 - YelpCamp skeleton

* Add Landing Page
* Add Campgrounds Pag that lists all campgrounds

Each Campground has:
* Name
* Image

-------
Pt.2 - Layout and Basic Styling 

* Create header and footer partials
* Add BootStrap

-------
Pt.3 - Creating New Campgrounds

* Setup new campground POST route
* Add in body-parser
* Setup route to show form
* Add basic unstyled form

--------
